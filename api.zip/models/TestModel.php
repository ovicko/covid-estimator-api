<?php

namespace api\models;

use Yii;


class TestModel extends \yii\db\ActiveRecord {

}