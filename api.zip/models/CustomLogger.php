<?php

namespace api\models;

use Yii;


class CustomLogger extends \yii\log\FileTarget {

    /**
     * Formats a log message for display as a string.
     * @param array $message the log message to be formatted.
     * The message structure follows that in [[Logger::messages]].
     * @return string the formatted message
     */
    public function formatMessage($message)
    {
        list($text, $level, $category, $timestamp) = $message;
        return "$text";
    }
}
